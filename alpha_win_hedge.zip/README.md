
# Painel Alpha WIN – Estratégia Inteligente Davi Maciel

Este painel simula estratégias automáticas de hedge e geração de lucro no mini índice WIN com base no cenário de mercado.

## Rodar localmente
```
pip install -r requirements.txt
streamlit run app.py
```
